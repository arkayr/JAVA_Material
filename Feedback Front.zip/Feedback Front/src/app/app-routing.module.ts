import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductfeedbackformComponent } from './feedback/productfeedbackform/productfeedbackform.component';
import { GetfeedbacksComponent } from './feedback/getfeedbacks/getfeedbacks.component';


const routes: Routes = [
  {path:"add",component:ProductfeedbackformComponent},
  {path:"get",component:GetfeedbacksComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
