import { Component, OnInit } from '@angular/core';
import { ProductFeedback } from '../ProductFeedback';
import { ProductfeedbackService } from '../productfeedback.service';

@Component({
  selector: 'app-getfeedbacks',
  templateUrl: './getfeedbacks.component.html',
  styleUrls: ['./getfeedbacks.component.css']
})
export class GetfeedbacksComponent implements OnInit {
feedbacks:ProductFeedback[];
  constructor(private productfeedbackservice:ProductfeedbackService) { 
    
  }

  ngOnInit() {
    this.feedbacks=this.productfeedbackservice.get();
  }

}
