import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';
import { ProductFeedback } from './ProductFeedback';

@Injectable({
  providedIn: 'root'
})
export class ProductfeedbackService {
  feedbacks: ProductFeedback[];
  constructor(private http: HttpClient) {
    this.populatefeedback().subscribe(data => this.feedbacks = data, error => console.log(error));
  }

  populatefeedback(): Observable<ProductFeedback[]> {
    return this.http.get<ProductFeedback[]>("http://localhost:8090/get");

  }
  addFeedback(feedback: ProductFeedback) {
    return this.http.post("http://localhost:8090/feedback", feedback).toPromise().then(data => console.log(data));

  }
  get() {
    console.log(this.feedbacks);
    return this.feedbacks;

  }
}
