export interface ProductFeedback {
	productFeedbackId: number;
	productId: number;
	feedback: String;
	rating: number
}