import { Component, OnInit } from '@angular/core';
import { ProductfeedbackService } from '../productfeedback.service';
import { Router } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'app-productfeedbackform',
  templateUrl: './productfeedbackform.component.html',
  styleUrls: ['./productfeedbackform.component.css']
})
export class ProductfeedbackformComponent implements OnInit {

  constructor(private productfeedback:ProductfeedbackService,private router:Router) { }

  ngOnInit() {
  }
  onSubmit(value)
  {
    console.log(value);
    this.productfeedback.addFeedback(value);
    this.router.navigate(['/get']);
  }
}
