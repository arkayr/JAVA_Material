import { Component, OnInit } from '@angular/core';
import { Promo } from '../../models/Promo';
import { CouponService } from '../coupon.service';
import { Router } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'app-list-coupon',
  templateUrl: './list-coupon.component.html',
  styleUrls: ['./list-coupon.component.css']
})
export class ListCouponComponent implements OnInit {

  constructor(private service:CouponService, private route: Router){}
  prom:Promo[]=[];
  promoId:number=0;
  ngOnInit(): void {
      //throw new Error("Method not implemented.");
      this.service.getPromocodes().subscribe(
          res=>{
             this.prom=res

          },
          err=>{
              alert("an error has occurred")
          }
      )
     }

     addPromocode(){
       this.route.navigate(['addPromocode']);
     }

     deletePromocode(data: number): any {
      this.promoId =  this.prom[data].promocodeId;
     if (this.service.deletePromocode(this.promoId).subscribe( data => {console.log(data);
     },
     error => console.log(error)

     ))
     {
       if (confirm('Are you Sure You Want To Delete')) {
         this.prom.splice(data, 1);
       }
     }
     }


     backtoadmin()
     {
       this.route.navigate(['coupon']);
     }

}
