import { Component, OnInit } from '@angular/core';
import { Promo } from '../../models/Promo';
import { Router } from '../../../../node_modules/@angular/router';
import { CouponService } from '../coupon.service';

@Component({
  selector: 'app-addcoupon',
  templateUrl: './addcoupon.component.html',
  styleUrls: ['./addcoupon.component.css']
})
export class AddcouponComponent implements OnInit {

  promocodeId:number;
  promocode:string;
  startdate:Date;
  enddate:Date;
  amount:string;
  prom:Promo
  constructor(private service:CouponService,private route:Router){}
  ngOnInit(){}

  save()
  {

      var  pro:Promo=new Promo(this. promocodeId,this.promocode,this.startdate,this.enddate,this.amount);
      console.log(pro);
      this.service.addPromocode(pro).subscribe(
          res=>{
              this.prom = res;
          }
      );
  }
  ch=false;
  change(){
      this.ch=true;
  }

  backtopromoCode(){
    this.route.navigate(['list']);
  }
}
