import { Injectable } from '@angular/core';
import { Promo } from '../models/Promo';
import { Observable } from '../../../node_modules/rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CouponService {

  constructor(private http: HttpClient) { }
  acc:Promo;
    addPromocode(pro: Promo) :Observable<Promo>
    {

         return this.http.post<Promo>("http://localhost:8001/addPromocode",pro);
    }

    getPromocodes()
    {
          return this.http.get<Promo[]>("http://localhost:8001/AllPromocodes");
    }

    deletePromocode(promocodeId:number)
    {

        return this.http.delete<Promo>("http://localhost:8001/deletePromoCode/"+promocodeId);

    }
}
