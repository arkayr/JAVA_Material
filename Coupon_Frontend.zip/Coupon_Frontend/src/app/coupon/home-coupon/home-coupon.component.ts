import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-coupon',
  templateUrl: './home-coupon.component.html',
  styleUrls: ['./home-coupon.component.css']
})
export class HomeCouponComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
