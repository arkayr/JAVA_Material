import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Injectable } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddcouponComponent } from './coupon/addcoupon/addcoupon.component';
import { ListCouponComponent } from './coupon/list-coupon/list-coupon.component';
import { HomeCouponComponent } from './coupon/home-coupon/home-coupon.component';

@NgModule({
  declarations: [
    AppComponent,
    AddcouponComponent,
    ListCouponComponent,
    HomeCouponComponent,
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule { }
