import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddcouponComponent } from './coupon/addcoupon/addcoupon.component';
import { ListCouponComponent } from './coupon/list-coupon/list-coupon.component';
import { AppComponent } from './app.component';
import { HomeCouponComponent } from './coupon/home-coupon/home-coupon.component';


const routes: Routes = [
  {path:"coupon",component:AddcouponComponent},
  {path:"list",component:ListCouponComponent},
  {path:"",component:HomeCouponComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
