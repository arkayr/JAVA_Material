package com.cg.fileupload.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.cg.fileupload.beans.Images;
import com.cg.fileupload.dao.ImageDao;

@Service
public class FileService {

	@Autowired
	private ImageDao imageRepository;
	private static final String FILE_DIRECTORY = "C:\\Users\\jmanku\\Downloads\\FileUploadVeru\\src\\main\\resources\\static\\images";

	public Images storeFile(MultipartFile file, int productId) throws IOException {
		System.out.println(productId + "  " + file.getOriginalFilename());
		Path filePath = Paths.get(FILE_DIRECTORY + "/" + productId + file.getOriginalFilename());
		Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
		Images image = new Images();
		image.setImageUrl(productId + file.getOriginalFilename());
		image.setProductId(productId);
		imageRepository.save(image);
		return image;
	}
}
