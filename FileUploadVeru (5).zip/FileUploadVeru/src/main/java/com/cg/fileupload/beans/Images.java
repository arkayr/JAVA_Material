package com.cg.fileupload.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Images {
	@Id
	@SequenceGenerator(name = "img_id", sequenceName = "img_id", initialValue = 100000, allocationSize = 1)
	@GeneratedValue(generator = "img_id")
	private int imageId;
	private String imageUrl;
	private int productId;
	public Images() {
		super();
	}
	public Images(String imageUrl, int productId) {
		super();
		this.imageUrl = imageUrl;
		this.productId = productId;
	}
	public int getImageId() {
		return imageId;
	}
	public void setImageId(int imageId) {
		this.imageId = imageId;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	@Override
	public String toString() {
		return "Images [imageId=" + imageId + ", imageUrl=" + imageUrl + ", productId=" + productId + "]";
	}

	

}
