package com.cg.fileupload.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.fileupload.beans.Images;
@Repository
public interface ImageDao extends JpaRepository<Images, Integer> {

}
