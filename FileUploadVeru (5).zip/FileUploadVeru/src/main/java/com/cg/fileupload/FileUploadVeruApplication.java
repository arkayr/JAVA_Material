package com.cg.fileupload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileUploadVeruApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileUploadVeruApplication.class, args);
	}

}
