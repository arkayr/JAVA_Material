import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ImageService {

  constructor(private http: HttpClient) { }

  uploadImage(formData,productId){
    this.http.post('http://localhost:5000/api/files/'+productId, formData).subscribe(data=>{
      console.log(data);
    })
  }
}
