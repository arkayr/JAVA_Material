package com.cg.coupon.service;

import java.util.List;

import com.cg.coupon.beans.Promocode;

public interface CouponService {
	public void addPromo(Promocode promo);
	public void deletePromo(int id);
	public List<Promocode> getAllPromos();
}
