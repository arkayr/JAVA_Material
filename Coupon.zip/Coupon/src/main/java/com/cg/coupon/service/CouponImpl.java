package com.cg.coupon.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.coupon.beans.Promocode;
import com.cg.coupon.dao.CouponDAO;



@Service
@Transactional
public class CouponImpl implements CouponService{

	@Autowired
	CouponDAO promoDao;
	
	@Override
	public void addPromo(Promocode promo) {
		// TODO Auto-generated method stub
		promoDao.save(promo);	
		
	}

	@Override
	public List<Promocode> getAllPromos() {
		// TODO Auto-generated method stub
		return promoDao.findAll();
	}


	@Transactional(propagation = Propagation.REQUIRED)
	public void deletePromo(int id) {
		// TODO Auto-generated method stub
		if (promoDao.existsById(id)) {
	         promoDao.deleteById(id);
		} else {
			System.out.println("Id not found");
		}
	}
}
