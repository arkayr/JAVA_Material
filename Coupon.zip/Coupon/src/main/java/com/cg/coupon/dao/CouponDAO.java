package com.cg.coupon.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.coupon.beans.Promocode;

public interface CouponDAO extends JpaRepository<Promocode, Integer>{

}
