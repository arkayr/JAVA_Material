package capgemini.labbook.Lab3;

import java.util.Arrays;

public class Lab3_Ex2_SortingStringArray {

	public static void main(String[] args) {

		String s[] = Lab3_Ex2_SortingStringArray
				.sortStringArray(new String[] { "hello", "arkay", "where", "are", "you" });
		for (String s1 : s) {
			System.out.print(s1 + "  ");
		}
	}

	public static String[] sortStringArray(String stringArray[]) {
		Arrays.sort(stringArray);
		if (stringArray.length % 2 == 0) {
			for (int i = 0; i < stringArray.length; i++) {
				if (i < (stringArray.length / 2)) {
					stringArray[i] = stringArray[i].toUpperCase();
				} else {
					stringArray[i] = stringArray[i].toLowerCase();
				}
			}
		} else {
			for (int i = 0; i < stringArray.length; i++) {
				if (i < (stringArray.length / 2) + 1) {
					stringArray[i] = stringArray[i].toUpperCase();
				} else {
					stringArray[i] = stringArray[i].toLowerCase();
				}
			}

		}
		return stringArray;
	}
}
