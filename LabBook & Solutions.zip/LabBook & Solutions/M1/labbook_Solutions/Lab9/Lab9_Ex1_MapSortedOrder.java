package capgemini.labbook.Lab9;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class Lab9_Ex1_MapSortedOrder {
	public static void main(String[] args) {
		HashMap<Integer, Integer> hash = new HashMap<Integer, Integer>();
		hash.put(1, 10);
		hash.put(2, 5);
		hash.put(8, 9);
		hash.put(3, 4);
		hash.put(9, 2);
		List list = getValues(hash);
		System.out.println(hash);
	}

	private static List getValues(HashMap hash) {
		List<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i < hash.size(); i++) {
			list.add(i);
		}
		Collections.sort(list);
		return list;
	}
}
