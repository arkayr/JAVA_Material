package capgemini.labbook;

public class Lab2_Ex1_Library {

	public static void main(String[] args) {
		Cd cd1 = new Cd();
		cd1.setArtist("veera");
		cd1.setGenre("pop");
		cd1.setIdentification_Number(100);
		cd1.setNumber_Of_Copies(170);
		cd1.setRuntime(5);
		cd1.setTitle("MarshMello");

		Vedio v1 = new Vedio();
		v1.setDirector("puri");
		v1.setGenre("pop");
		v1.setYearRealeased(2018);
		v1.setIdentification_Number(101);
		v1.setNumber_Of_Copies(2850);
		v1.setRuntime(4);
		v1.setTitle("Shape Of You");

		book b1 = new book();
		b1.setAuthor("Chetan Bhagat");
		b1.setIdentification_Number(102);
		b1.setNumber_Of_Copies(150);
		b1.setTitle("Two States");

		JournalPaper p1 = new JournalPaper(2018);
		p1.setAuthor("arkay");
		p1.setIdentification_Number(103);
		p1.setNumber_Of_Copies(199);
		p1.setTitle("JAVA");

		System.out.println("cd:\n" + cd1+"\n");

		System.out.println("vedio:\n" + v1+"\n");

		System.out.println("book:\n" + b1+"\n");

		System.out.println("Journal:\n" + p1+"\n");

	}

}
