package capgemini.labbook;

public abstract class MediaItem extends Item {
	protected int runtime;

	public abstract int getRuntime();

	public abstract void setRuntime(int runtime);

}
