package capgemini.labbook;

public class JournalPaper extends WrittenItem {

	private int yearpublished;

	public JournalPaper() {
		yearpublished = 0;
	}

	public JournalPaper(int yearpublished) {
		super();
		this.yearpublished = yearpublished;
	}

	@Override
	public String getAuthor() {
		return author;
	}

	@Override
	public void setAuthor(String author) {
		this.author = author;
	}

	@Override
	public int getIdentification_Number() {
		return identification_Number;
	}

	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public String toString() {
		return "JournalPaper [yearpublished=" + yearpublished + ", author=" + author + ", identification_Number="
				+ identification_Number + ", title=" + title + ", number_Of_Copies=" + number_Of_Copies + "]";
	}

	@Override
	public int getNumber_Of_Copies() {
		return number_Of_Copies;
	}

	@Override
	public void setIdentification_Number(int identification_Nmuber) {
		this.identification_Number = identification_Nmuber;
	}

	@Override
	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public void setNumber_Of_Copies(int number_Of_Copies) {
		this.number_Of_Copies = number_Of_Copies;
	}

}
