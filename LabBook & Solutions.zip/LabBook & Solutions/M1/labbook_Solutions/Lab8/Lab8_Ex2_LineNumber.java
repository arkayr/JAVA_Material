package capgemini.labbook.Lab8;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

public class Lab8_Ex2_LineNumber {
public static void main(String[] args) {
	File file= new File("D:\\capgemini\\Readme.txt");
	try {
		FileReader fileInput= new FileReader(file);
		@SuppressWarnings("resource")
		LineNumberReader lineNumber=new LineNumberReader(fileInput);
		try {
			String sc= lineNumber.readLine();
			while(sc!=null){
				System.out.println(lineNumber.getLineNumber()+" "+sc);
				sc=lineNumber.readLine();
			}
		} catch (IOException e) {
			System.out.println("IOException");
		}
	} catch (FileNotFoundException e) {
		System.out.println("FileNotFoundException");
	}
}
}
