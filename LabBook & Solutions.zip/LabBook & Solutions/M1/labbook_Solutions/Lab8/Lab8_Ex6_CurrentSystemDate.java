package capgemini.labbook.Lab8;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class Lab8_Ex6_CurrentSystemDate {

	public static void main(String[] args) {
		System.out.println("Enter the Date :YY-MM-DD ");
		@SuppressWarnings("resource")
		Scanner scaner = new Scanner(System.in);
		String d = scaner.nextLine();
		LocalDate now = LocalDate.now();
		LocalDate dt = LocalDate.parse(d);
		Period dif = Period.between(dt, now);
		System.out.println("Difference is :\t" + dif.getDays() + " Days \t" + dif.getMonths() + " Months \t"
				+ dif.getYears() + " Years");
	}

}
