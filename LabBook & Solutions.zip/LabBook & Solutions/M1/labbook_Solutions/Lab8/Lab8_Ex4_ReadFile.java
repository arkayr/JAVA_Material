package capgemini.labbook.Lab8;

import java.io.File;

public class Lab8_Ex4_ReadFile {

	public static void main(String[] args) {
		String path = "your file";
		File file = new File(path);
		if (file.exists() && file.canRead() && file.canWrite()) {
			System.out.println("Given file is existed and it can readable and writable");
		} else {
			System.out.println("Given file is not existed and it can't readable and can't writable");
		}
		System.out.println(file.length());
		// for(int i=0;i<path.length();i++))
		int index = path.lastIndexOf('.');
		System.out.println(path.substring(index + 1));

	}
}
