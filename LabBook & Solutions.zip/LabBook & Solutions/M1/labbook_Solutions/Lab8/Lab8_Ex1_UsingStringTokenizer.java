package capgemini.labbook.Lab8;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Lab8_Ex1_UsingStringTokenizer {

	public static void main(String[] args) {
		System.out.println( "enter numbers");
		Scanner scaner = new Scanner(System.in);
		String s = scaner.nextLine();
		StringTokenizer st = new StringTokenizer(s, ", ");
		int n, sum = 0;
		while (st.hasMoreTokens()) {
			n = Integer.parseInt(st.nextToken());
			System.out.println(n + " ");
			sum = sum + n;
		}
		System.out.println("sum:" + sum);
		scaner.close();

	}

}
