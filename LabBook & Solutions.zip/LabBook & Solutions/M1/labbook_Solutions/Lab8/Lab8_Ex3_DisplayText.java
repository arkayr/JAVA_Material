package capgemini.labbook.Lab8;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Lab8_Ex3_DisplayText {
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		File file = new File("D:\\capgemini\\Readme.txt");
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(file));
			int charCount = 0, wordCount = 0, lineCount = 0;
			String currLine;
			while ((currLine = reader.readLine()) != null) {
				lineCount++;
				String[] word = currLine.split(" ");
				wordCount += word.length;
				for (String words : word) {
					charCount += word.length;
				}
			}
			System.out.println("Number of Lines:"+lineCount);
			System.out.println("Number of words:"+wordCount);
			System.out.println("number of Chars:"+charCount);

		} catch (FileNotFoundException e) {

			System.out.println("FileNotFound");
		} catch (IOException e) {
			 System.out.println("IOException");
		}
	}
}
