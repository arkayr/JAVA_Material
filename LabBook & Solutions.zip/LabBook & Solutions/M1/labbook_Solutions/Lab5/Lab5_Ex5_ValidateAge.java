package capgemini.labbook.Lab5;

import java.util.Scanner;

public class Lab5_Ex5_ValidateAge {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter age");
		int age = sc.nextInt();
		try {
			if (age < 15)
				throw new AgeException("you're not alllowed");
			System.out.println("welcome....your age is verified");
		} catch (AgeException e) {
			e.getMessage();
		} finally {
			sc.close();

		}
	}

}

class AgeException extends Exception {
	/*
	 */
	private static final long serialVersionUID = 6818822310140947371L;

	AgeException(String s) {
		System.out.println(s);
	}
}
