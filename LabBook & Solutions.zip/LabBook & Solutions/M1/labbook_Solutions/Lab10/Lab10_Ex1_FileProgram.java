package capgemini.labbook.Lab10;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class Lab10_Ex1_FileProgram {
	public static void main(String[] args) {
		try {
			FileInputStream fileInputStream = new FileInputStream(new File("C:\\Capgemini\\Files\\Lab10_Ex1_SourceFile.txt"));
			FileOutputStream fileOutputStream = new FileOutputStream(new File("C:\\Capgemini\\Files\\Lab10_Ex1_TargetFile.txt"));
			Lab10_Ex1_CopyDataThread copyDataThread = new Lab10_Ex1_CopyDataThread(fileInputStream, fileOutputStream);
			copyDataThread.start();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

}
