package capgemini.labbook.Lab10;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Lab10_Ex1_CopyDataThread extends Thread {
	FileInputStream fileInputStream;
	FileOutputStream fileOutputStream;

	public Lab10_Ex1_CopyDataThread(FileInputStream fileInputStream, FileOutputStream fileOutputStream) {
		super();
		this.fileInputStream = fileInputStream;
		this.fileOutputStream = fileOutputStream;
	}

	@Override
	public void run() {
		int count = 1, input = 0;

		try {
			while ((input = fileInputStream.read()) != -1) {
				System.out.println((char)input + " "+count);
				if (count == 10) {
					System.out.println("10 characters are copied");
					Thread.sleep(5000);
					count = 0;
				}
				fileOutputStream.write(input);
				count++;

			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
