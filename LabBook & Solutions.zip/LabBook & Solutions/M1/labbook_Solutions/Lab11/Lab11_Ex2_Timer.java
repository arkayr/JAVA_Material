package capgemini.labbook.Lab11;
import java.time.LocalTime;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
public class Lab11_Ex2_Timer {

	public static void main(String[] args) {

		ExecutorService serv = Executors.newSingleThreadExecutor();

		Runnable timer = new Runnable() {
			@Override
			public void run() {
				while (true) {
					LocalTime localTime = LocalTime.now();
					System.out.println("Time : " + localTime);
					try {
						TimeUnit.SECONDS.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		};

		serv.submit(timer);
		serv.shutdown();
	}
}

