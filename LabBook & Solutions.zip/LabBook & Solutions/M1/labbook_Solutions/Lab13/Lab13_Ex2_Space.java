package capgemini.labbook.Lab13;

import java.util.function.Consumer;

public class Lab13_Ex2_Space {
	public static void main(String[] args) {
		Consumer<String> cons = (string) -> {
			for (int i = 0; i < string.length(); i++) {
				System.out.print(string.substring(i, i + 1) + " ");
			}
			;
		};
		cons.accept("veeru");
	}

}
