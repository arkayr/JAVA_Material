package capgemini.labbook.Lab14;

public interface EmployeeServiceInterface {
	public Employee insuranceScheme(Employee e);
	public String designation(Employee e);
}
