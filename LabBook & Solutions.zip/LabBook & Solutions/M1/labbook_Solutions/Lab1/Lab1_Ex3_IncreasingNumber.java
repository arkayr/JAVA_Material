package capgemini.labbook.Lab1;

import java.util.Arrays;

public class Lab1_Ex3_IncreasingNumber {

	public static void main(String[] args) {
		boolean bool = checkNumber(123456789);
		if (bool == true)
			System.out.println("increasing number");
		else
			System.out.println("not an increasing number");
	}

	public static boolean checkNumber(int number) {
		String num = Integer.toString(number);
		char ar1[] = new char[num.length()];
		char br1[] = new char[num.length()];
		for (int i = 1; i < num.length(); i++) {
			char ss = num.charAt(i);
			ar1[i] = ss;
			br1[i] = ss;
		}
		Arrays.sort(ar1);
		if (Arrays.equals(ar1, br1))
			return true;
		else
			return false;

	}

}
