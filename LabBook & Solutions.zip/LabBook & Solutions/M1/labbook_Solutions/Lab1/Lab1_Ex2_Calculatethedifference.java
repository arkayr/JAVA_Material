package capgemini.labbook.Lab1;

public class Lab1_Ex2_Calculatethedifference {
	public static void main(String[] args) {
		System.out.println(calculateDifference(10));
	}

	public static int calculateDifference(int n) {
		int sum1 = 0, sum2 = 0, sum;
		for (int i = 1; i <= n; i++) {
			sum1 = sum1 + (i * i);
			sum2 = sum2 + i;
		}
		sum = sum1-(sum2*sum2);
		return sum;
	}
}
