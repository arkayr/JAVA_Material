package capgemini.labbook.Lab1;

public class Lab1_Ex4_PowerOfTwo {

	public static void main(String[] args) {
		if(CheckNumber(16))
			System.out.println("power of 2");
		else 
			System.out.println("not a power of 2");
	}
public static boolean CheckNumber(int n){
	double doub = (Math.log(n)/Math.log(2));
	int i = (int)doub;
	if(doub== i )
		return true;
	else
		return false;
}
}
