package com.feedback.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.feedback.bean.ProductFeedback;
import com.feedback.service.FeedbackService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class ProductFeedbackController {
	
	@Autowired
	private FeedbackService feedBackService;
	
	@PostMapping("/feedback")
	public void addFeedback(@RequestBody ProductFeedback prod)
	{
		feedBackService.addFeedBack(prod);
	}
	
	@GetMapping("/get")
	public List<ProductFeedback> getAll()
	{
		return feedBackService.getAll();
	}

}
