package com.feedback.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.feedback.bean.ProductFeedback;

@Repository
public interface ProductFeedbackRepo extends JpaRepository<ProductFeedback, Integer> {

}
