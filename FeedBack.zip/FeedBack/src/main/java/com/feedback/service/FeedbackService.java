package com.feedback.service;

import java.util.List;

import com.feedback.bean.ProductFeedback;

public interface FeedbackService {

	void addFeedBack(ProductFeedback prod);

	List<ProductFeedback> getAll();

}
