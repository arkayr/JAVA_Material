package com.feedback.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.feedback.bean.ProductFeedback;
import com.feedback.dao.ProductFeedbackRepo;

@Service
public class FeedbackServiceImpl implements FeedbackService {
	
	@Autowired
	private ProductFeedbackRepo repo;

	@Override
	public void addFeedBack(ProductFeedback prod) {
		System.out.println(prod);
		repo.save(prod);
		
	}

	@Override
	public List<ProductFeedback> getAll() {
	
		return repo.findAll();
	}

}
