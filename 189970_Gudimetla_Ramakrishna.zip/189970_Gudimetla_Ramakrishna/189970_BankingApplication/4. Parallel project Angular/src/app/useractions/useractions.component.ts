import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-useractions',
  templateUrl: './useractions.component.html',
  styleUrls: ['./useractions.component.css']
})
export class UseractionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
