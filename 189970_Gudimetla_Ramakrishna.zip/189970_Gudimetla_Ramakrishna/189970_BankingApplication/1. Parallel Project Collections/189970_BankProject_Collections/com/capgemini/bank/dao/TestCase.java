package com.capgemini.bank.dao;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.capgemini.bank.user.bean.UserBean;

public class TestCase {

	UserBean bean = new UserBean("Kumar222", "Kumar123", "Vaibhav", 998855663, 450);
	DaoClass storage = new DaoClass();

	@Test
	public void getId() {

		int id = storage.userAccountCreation("Kumar222", bean);
		assertEquals(null, id);

	}

	@Test
	public void getId1() {

		int id = storage.userAccountCreation("Kumar222", bean);
		int expected = 1;
		assertEquals(expected, id);

	}

}