package com.capgemini.bank.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import com.capgemini.bank.user.bean.UserBean;

import java.text.*;

public class DaoClass implements DaoInterface {
	HashMap<String, UserBean> UserAccountData;

	public DaoClass() {
		UserAccountData = new HashMap<String, UserBean>();
	}

	UserBean ub; // Object of Userbean class.

	SimpleDateFormat sd = new SimpleDateFormat("dd/MM/yyyy");
	SimpleDateFormat sd1 = new SimpleDateFormat("HH:mm:ss");

	// this method create user account and data in map collection.
	
	
	@Override
	public int userAccountCreation(String accountId, UserBean userbean) {

		UserAccountData.put(accountId, userbean);
		return 1;
	}

	// this method return account balance .

	@Override
	public String showBalance(String accountId) {

		ub = UserAccountData.get(accountId);
		return "Balance is " + ub.getBalance();

	}

	// this method use for deposit amount.
	
	
	@Override
	public String Deposit(String accountId, int amount) {

		ub = UserAccountData.get(accountId);
		ub.setBalance(ub.getBalance() + amount);
		String date = sd.format(new Date());
		String time = sd1.format(new Date().getTime());

		ub.setTransaction("Transaction type = Deposit || fromAccount = " + accountId + " || Amount = " + amount
				+ "|| Date =" + date + "|| Time = " + time);
		return "After deopsit user balance is " + ub.getBalance();
	}

	// this method use for withdraw amount.
	
	
	@Override
	public String withDraw(String accountId, int amount) {
		ub = UserAccountData.get(accountId);
		ub.setBalance(ub.getBalance() - amount);
		String date = sd.format(new Date());
		String time = sd1.format(new Date().getTime());
		ub.setTransaction("Transaction type = WithDraw || fromAccount = " + accountId + " || Amount = " + amount
				+ "|| Date =" + date + "|| Time = " + time);
		return "After withdraw user balance is " + ub.getBalance();
	}

	/* this method use to sign in into account.
	 return 1 if valid ,else return 0.*/
	
	
	
	@Override
	public int LogIn(String accountId, String accountPassword) {
		if (UserAccountData.containsKey(accountId)) {
			ub = UserAccountData.get(accountId);
			if (ub.getAccountPassword().equals(accountPassword)) {
				return 1;
			} else {
				return 0;
			}
		} else {
			return 0;
		}

	}

	/* this method use for fund transfer data.
	 sourceAccountId = user one who want to transfer amount.
	 destrinationAccountId = user whom to transfer amount.
	 
	 */
	
	
	@Override
	public String fundTransfer(String sourceAccountId, String destinationAccountId, int amount) {
		ub = (UserBean) UserAccountData.get(sourceAccountId);
		if (ub.getBalance() >= amount) {
			String date = sd.format(new Date());
			String time = sd1.format(new Date().getTime());
			UserBean a2;
			a2 = UserAccountData.get(destinationAccountId);
			ub.setBalance(ub.getBalance() - amount);
			a2.setBalance(a2.getBalance() + amount);
			ub.setTransaction("Transaction type = Fund Transfer || fromAccount = " + sourceAccountId + " || toAccount ="
					+ destinationAccountId + " || Amount = " + amount + "|| Date =" + date + "|| Time = " + time);
			a2.setTransaction("Transaction type = Fund Transfer || fromAccount = " + sourceAccountId + " || toAccount ="
					+ destinationAccountId + " || Amount = " + amount + "|| Date =" + date + "|| Time = " + time);
			return "After transfer fund your balance is " + ub.getBalance();
		} else {
			return "You have insufficient amount to transfer";
		}

	}

	// this method print the all transaction of logged in user.
	@Override
	public String printTransactions(String accountId) {
		ub = UserAccountData.get(accountId);

		String s = "";
		Iterator i = ub.getTransaction().iterator();
		while (i.hasNext()) {
			s = s + "\n" + (String) i.next();
		}
		return s;
	}

	// this method check account id is in collection or not.
	@Override
	public boolean validAccountId(String accountId) {
		if (UserAccountData.containsKey(accountId)) {
			return true;
		} else {
			return false;
		}
	}

	// this method check user have insufficient balance or not.
	@Override
	public boolean checkBalance(String accountId, int amount) {
		ub = (UserBean) UserAccountData.get(accountId);
		if (ub.getBalance() >= amount) {
			return true;
		} else {
			return false;
		}
	}

}
