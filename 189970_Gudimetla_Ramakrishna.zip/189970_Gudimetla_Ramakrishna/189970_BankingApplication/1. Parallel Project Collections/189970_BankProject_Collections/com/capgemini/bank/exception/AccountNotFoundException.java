package com.capgemini.bank.exception;

///Exception throw when account id is not found.

public class AccountNotFoundException extends RuntimeException {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public AccountNotFoundException(String message) {
	super(message);
	}
}
