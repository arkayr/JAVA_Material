import { Component, OnInit } from '@angular/core';
import { BankserviceService } from 'src/app/services/bankservice.service';
import { UserTransactions } from 'src/app/models/userTransactions';

@Component({
  selector: 'app-usertransactions',
  templateUrl: './usertransactions.component.html',
  styleUrls: ['./usertransactions.component.css']
})
export class UsertransactionsComponent implements OnInit {

  transactions:UserTransactions[] = [];

  constructor(
    private bankService:BankserviceService
  ) { }

  ngOnInit() {
    var transactionsObj = this.bankService.PrintTransactions();
    transactionsObj
                  .subscribe((data) => {
                    this.transactions = data;
                  })
  }

}





   /*  this.transactions = this.bankService.PrintTransactions();
    console.log(this.transactions)

  }

}
 */