package com.capgemini.bank.dao;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.capgemini.bank.exception.AccountNotFoundException;
import com.capgemini.bank.user.bean.UserBean;


	
//	public class TestCase {
//
//		UserBean bean = new UserBean("VA112233", "Kumar123", "Vaibhav", 998855663, 450);
//		DaoClass storage = new DaoClass();
//
//		@Test
//		public void getId() {
//
//			int id = storage.userAccountCreation("VA112233", bean);
//			assertEquals(null, id);
//
//		}
//
//		@Test
//		public void getId1() {
//
//			int id = storage.userAccountCreation("VA112233", bean);
//			int expected = 1;
//			assertEquals(expected, id);
//
//		}
//
//	}
//	




//public class TestCase {
//
//	 
//
//    UserBean bean = new UserBean("Aabc1234", "Abha", "Mahja", 450);
//    DaoClass storage = new DaoClass();
//
// 
//
//    @Test
//    public void getId() throws AccountNotFoundException {
//
// 
//
//        String id = storage.createAccount(bean);
//        assertEquals(null, id);
//
// 
//
//    }
//
// 
//
//    @Test
//    public void getId1() throws ClassNotFoundException, SQLException {
//
// 
//
//        String id = storage.createAccount(bean);
//        String expected = "     ";
//        assertEquals(expected.length(), id.length());
//
// 
//
//    }
//    @Before
//    public void getUser() {
//
// 
//
//        boolean actual = storage.authenticateUser("18657", "Aabc1234");
//        boolean expected =true;
//        Assert.assertEquals(expected, actual);
//
// 
//
//    }
//
// 
//
//
//    @Test
//    public void getBalance()  {
//
// 
//
//        double balance = storage.showBalance();
//        double expected =450;
//        Assert.assertEquals(expected, balance, 0);
//
// 
//
//    }
//
// 
//
//}
//	
	

